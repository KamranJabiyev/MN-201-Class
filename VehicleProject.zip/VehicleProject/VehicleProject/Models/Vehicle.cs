﻿namespace VehicleProject.Models;

public class Vehicle
{
    public string Color;
    public int Year;
    public Vehicle(int year)
    {
        Year = year;
    }

    public Vehicle(int year,string color):this(year)
    {
        Color = color;
    }

    public virtual void ShowInfo()
    {
        Console.WriteLine($"Year: {Year}; \n Color:{Color}");
    }
}
