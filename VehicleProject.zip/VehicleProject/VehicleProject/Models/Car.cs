﻿namespace VehicleProject.Models;

public class Car : Vehicle
{
    public string Brand;
    public string Model;
    public double FuelCapacity;
    public double CurrentfuelLevel;
    public double Cumpsuption;
    public Car(int year,
        string color,
        string brand,
        string model,
        double fuelCapacity,
        double currentfuelLevel,
        double cumpsuption) : base(year,color)
    {
        Brand = brand;
        Model = model;
        FuelCapacity = fuelCapacity;
        CurrentfuelLevel = currentfuelLevel;
        Cumpsuption = cumpsuption;
    }

    public override void ShowInfo()
    {
        Console.WriteLine($" Year: {Year}; " +
            $"\n Color:{Color};" +
            $"\n Brand:{Brand};" +
            $"\n Model:{Model};" +
            $"\n FuelCapacity:{FuelCapacity} l;" +
            $"\n CurrentfuelLevel: {CurrentfuelLevel} l;" +
            $"\n Cumpsuption:{Cumpsuption} l/100km;");
    }

    public void Drive(int km)
    {
        double maxKm = CurrentMaxDrivingKm();

        if(maxKm >= km)
        {
            CurrentfuelLevel = ((maxKm - km) /100) *Cumpsuption;
            Console.WriteLine($"Mesafe qet edildi. Hazirki yanacaq seviyyesi: {CurrentfuelLevel}");
        }
        else
        {
            if (MaxDrivingKm() >= km)
            {
                double requiredFuel = ((km - CurrentMaxDrivingKm()) / 100)* Cumpsuption;
                Console.WriteLine($"Bu mesafe uchun elave {requiredFuel} litr yanacaq lazimdir");
            }
            else
            {
                Console.WriteLine("Bir dolu bakla bu mesafeni getmek mumkun deyil");
            }
        }
    }

    public double CurrentMaxDrivingKm()
    {
        return (CurrentfuelLevel / Cumpsuption) * 100;
    }

    public double MaxDrivingKm()
    {
        return (FuelCapacity / Cumpsuption) * 100;
    }
}
