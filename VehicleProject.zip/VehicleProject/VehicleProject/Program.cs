﻿using VehicleProject.Models;

Car uaz = new Car(1988, "bej", "UAZ", "2130", 80, 40, 20);
uaz.ShowInfo();
//Console.WriteLine(uaz.CurrentMaxDrivingKm());
uaz.Drive(150);
