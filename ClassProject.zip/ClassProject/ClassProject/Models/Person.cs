﻿namespace ClassProject.Models;

public class Person
{
    public string Name;
    public string Surname;
    public int Age;
    public Person()
    {
        
    }
    public Person(string name)
    {
        Console.WriteLine("Person created");
    }

    public virtual void Detail()
    {
        Console.WriteLine($"{Name} {Surname} {Age}");
    }
}
