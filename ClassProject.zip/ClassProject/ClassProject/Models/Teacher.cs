﻿namespace ClassProject.Models;

public class Teacher:Person
{
    //fields
    public string[] Knowledges;
    public double Salary;
    public Teacher(string name, string surname,int age,double salary)
    {
        Name = name;
        Surname = surname;
        Age = age;
        Salary = salary;
    }

    //Method overriding - dinamic polymorphism(run time)
    public override void Detail()
    {
        Console.WriteLine($"{Name} {Surname} {Age} {Salary}");
    }
}
