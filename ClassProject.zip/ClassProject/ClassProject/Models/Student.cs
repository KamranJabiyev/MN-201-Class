﻿namespace ClassProject.Models;
//inheretance - miras almaq
public class Student:Person //is a
{
    //fields
    public string Phone;

    //Method signature - method name,parameters' count, parameters type and queue
    //Method overloading - compile time, static polymorphism
    public Student()
    {
        Console.WriteLine("New Student created");
    }

    public Student(string name, string surname)
    {
        Name = name;
        Surname = surname;
    }

    public Student(string name, string surname,int age):this(name,surname)
    {
        Age = age;
    }
}
