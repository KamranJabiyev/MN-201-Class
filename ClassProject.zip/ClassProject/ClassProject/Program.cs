﻿#region Anonim object

//var stu1 = new
//{
//    name="Ravil",
//    surname="Ceferzade",
//    age=29
//};

//var stu2 = new
//{
//    name = "Babek",
//    surname = "Murselov",
//    age = 24
//};

//Console.WriteLine(stu2.name);
#endregion

#region Class
using ClassProject.Models;
// instance
Person stu1 = new Student("Ravil","Ceferzade",29);

Person stu2 = new Student("Babek","Murselov");

Person teacher1 = new Teacher("Kamran", "Jabiyev", 33, 1000);

stu1.Detail();
stu2.Detail();
teacher1.Detail();
#endregion
