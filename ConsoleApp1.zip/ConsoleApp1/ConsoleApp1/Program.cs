﻿


#region For
//for (int i = 1; i <= 10; i++)
//{
//    if(i ==5) continue;
//    Console.WriteLine(i);
//}
//infinity loop
//for (; ; )
//{
//    if ()
//    {
//        break;
//    }
//}
#endregion

#region While
//int number = 0;
//while (number < 10)
//{
//    Console.WriteLine(++number);
//}

//do
//{
//    Console.WriteLine(number);
//    number++;
//} while (number < 10);
#endregion

#region Statement

//if (day == 0)
//{
//    Console.WriteLine("Monday");
//}else if (day == 1)
//{
//    Console.WriteLine("Tuesday");
//}else if(day == 2)
//{
//    Console.WriteLine("Wednesday");
//}
//else
//{
//    Console.WriteLine("Other day");
//}
//switch (day)
//{
//	case 0:
//    case 1:
//    case 2:
//    case 3:
//    case 4:
//        Console.WriteLine("weekday");
//        break;
//    case 5:
//    case 6:
//        Console.WriteLine("weekend");
//        break;
//    default:
//        Console.WriteLine("Not correct format");
//        break;
//}
//int day = 5;
//string message = day switch
//{
//    _ when day<5 => "weekday",
//    _ when day<=6=>"weekend",
//    _=>"Wrong format"
//};
//Console.WriteLine(message);
#endregion

#region Task
//int n = 10;
//int sum = 0;
//for (int i = 1;i<= n; i++)
//{
//    if (i % 3 == 0)
//    {
//        sum += i;
//    }
//}

//Console.WriteLine(sum);

//int num = 2357;
//bool isSingle=true;
//for (int i = 2; i*i <= num; i++)
//{
//    if(num%i == 0)
//    {
//        Console.WriteLine("Murekkeb eded");
//        isSingle = false;
//        break;
//    }
//}

//if (isSingle)
//{
//    Console.WriteLine("Sade eded");
//}

#endregion


#region Function
//Console.WriteLine(Sum(5,10));

//string word = "Hello";
//int Sum(int n1,int n2) //n1,n2
//{
//    return n1+n2;
//}

//long Multiple(int a, int b=5)
//{
//    return a * b;
//}

//long result = Multiple(2,3); //2 and 3 -argument
//Console.WriteLine(result);

//void Fullname(string name,string surname)
//{
//    //string fullname = name +" "+ surname;    
//    string fullname = $"{name} {surname}";
//    Console.WriteLine(fullname);
//}
//Fullname("Kamran", "Movsumov");

//int[] arr = {-100,-20,-30,-13,-45 };
//int[] arr = new int[4] { 1, 2, 3,4 };
//Console.WriteLine(arr[arr.Length-1] );
//Console.WriteLine(arr[^1]);

//int MaxValue(params int[] arr)
//{
//    int max = arr[0];
//	for (int i = 1; i < arr.Length; i++)
//	{
//        if (arr[i] > max)
//        {
//            max= arr[i];
//        }
//    }
//    return max;
//}
//MaxValue(20,12,3,45,10,76);
//Console.WriteLine(MaxValue(arr));
#endregion

#region Reference & Value
//int a = 5;
//int b = a; //b=5
//a = 10;
//Console.WriteLine($"a={a}");
//Console.WriteLine($"b={b}");

//int[] arr1 = {10,20,30,40};
//int[] arr2 = {10,20,30,40};
//int[] arr2 = arr1;
//arr1[0] = 1000;
//Console.WriteLine($"arr1={arr1[0]}");
//Console.WriteLine($"arr2={arr2[0]}");
//Console.WriteLine(arr1==arr2);

int a;
PrintNumber(out a);
Console.WriteLine(a);
void PrintNumber(out int a)
{
    a = 100;
    Console.WriteLine($"inside method = {a}");
}

//int[] arr = { 10,20,30};
//PrintIndex(arr);
//Console.WriteLine($"arr={arr[0]}");
//void PrintIndex(int[] arr)
//{
//    arr[0] = 500;
//    Console.WriteLine($"method - arr={arr[0]}");
//}
#endregion

